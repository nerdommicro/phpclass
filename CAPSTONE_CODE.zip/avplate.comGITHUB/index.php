


<?php
static $heading1 = "Welcome to our custom wall plate store";
static $title ;
session_start();
error_reporting(E_ERROR);

?>
<html>
<head></head>
<title>Welcome to AV Plates</title>
<body>
<br><br><br><br><br><br>This page has moved! <a href="http://www.customwallplates.com">Click here</a> to continue to Customwallplates.com USA
</body>



</html>  
