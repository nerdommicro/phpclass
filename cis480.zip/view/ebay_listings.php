<?php
$heading = "Ebay Listings";
include_once('products.php');