<?php
$heading = "Images List";
include_once('products.php');